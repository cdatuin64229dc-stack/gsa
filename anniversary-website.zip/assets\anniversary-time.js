(() => {
  'use strict';

  const TIME_ZONE = 'Asia/Manila';
  const FIRST_ANNIVERSARY = Object.freeze({ year: 2026, month: 11, day: 23 });
  const $ = id => document.getElementById(id);
  const pad = value => String(value).padStart(2, '0');
  const partsFormatter = new Intl.DateTimeFormat('en-US', { timeZone: TIME_ZONE, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' });
  const clockFormatter = new Intl.DateTimeFormat('en-PH', { timeZone: TIME_ZONE, hour: 'numeric', minute: '2-digit', second: '2-digit', hour12: true });
  const dateFormatter = new Intl.DateTimeFormat('en-PH', { timeZone: TIME_ZONE, weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
  const civilFormatter = new Intl.DateTimeFormat('en-US', { timeZone: 'UTC', month: 'long', day: 'numeric', year: 'numeric' });
  const fullCivilFormatter = new Intl.DateTimeFormat('en-US', { timeZone: 'UTC', weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
  const monthFormatter = new Intl.DateTimeFormat('en-US', { timeZone: 'UTC', month: 'long', year: 'numeric' });
  function manilaParts(instant = new Date()) {
    const values = {};
    for (const part of partsFormatter.formatToParts(instant)) if (part.type !== 'literal') values[part.type] = Number(part.value);
    return values;
  }
  function dateKey(date) { return date.year + '-' + pad(date.month) + '-' + pad(date.day); }
  function civilInstant(date) { return new Date(Date.UTC(date.year, date.month - 1, date.day)); }
  function civilFromInstant(date) { return { year: date.getUTCFullYear(), month: date.getUTCMonth() + 1, day: date.getUTCDate() }; }
  function ordinal(number) {
    const tail = number % 100;
    return number + (tail >= 11 && tail <= 13 ? 'th' : ({ 1: 'st', 2: 'nd', 3: 'rd' }[number % 10] || 'th'));
  }
  function celebrationForDay(date) {
    if (date.day !== 23) return null;
    if (date.month === 11 && date.year >= FIRST_ANNIVERSARY.year) {
      const number = date.year - FIRST_ANNIVERSARY.year + 1;
      return { kind: 'anniversary', number, title: 'Happy ' + ordinal(number) + ' anniversary, beby!', detail: ordinal(number) + ' anniversary & monthsary' };
    }
    return { kind: 'monthsary', title: 'Happy monthsary, beby!', detail: 'Our monthsary' };
  }
  function nextMonthsary(instant = new Date()) {
    const now = manilaParts(instant);
    let date = { year: now.year, month: now.month, day: 23 };
    if (now.day > 23) date = civilFromInstant(new Date(Date.UTC(now.year, now.month, 23)));
    return date;
  }
  function nextAnniversary(instant = new Date()) {
    const now = manilaParts(instant);
    let year = Math.max(FIRST_ANNIVERSARY.year, now.year);
    if (year === now.year && (now.month > 11 || now.month === 11 && now.day > 23)) year++;
    return { year, month: 11, day: 23 };
  }
  function daysUntil(date, instant = new Date()) { return Math.round((civilInstant(date) - civilInstant(manilaParts(instant))) / 86400000); }
  function validTime(value) { return typeof value === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(value); }
  function reminderFor(instant, time, lastNotified = '') {
    if (!validTime(time)) return null;
    const now = manilaParts(instant);
    const celebration = celebrationForDay(now);
    const [hour, minute] = time.split(':').map(Number);
    if (!celebration || now.hour * 60 + now.minute < hour * 60 + minute || lastNotified === dateKey(now)) return null;
    return { ...celebration, date: dateKey(now) };
  }
  function escapeCalendarText(value) { return value.replace(/\\/g, '\\\\').replace(/\n/g, '\\n').replace(/,/g, '\\,').replace(/;/g, '\\;'); }
  function makeCalendar(time = '09:00', instant = new Date()) {
    if (!validTime(time)) throw new Error('Invalid reminder time');
    const [hour, minute] = time.split(':').map(Number);
    const stamp = instant.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}Z$/, 'Z');
    const start = '20261123T' + pad(hour) + pad(minute) + '00';
    const lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Beby and Leplep//Our Special Dates//EN', 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH', 'X-WR-CALNAME:Our special dates', 'X-WR-TIMEZONE:' + TIME_ZONE,
      'BEGIN:VTIMEZONE', 'TZID:' + TIME_ZONE, 'X-LIC-LOCATION:' + TIME_ZONE, 'BEGIN:STANDARD', 'DTSTART:19700101T000000', 'TZOFFSETFROM:+0800', 'TZOFFSETTO:+0800', 'TZNAME:PhST', 'END:STANDARD', 'END:VTIMEZONE'];
    const events = [
      { uid: 'monthsary-23', summary: 'Our monthsary', rule: 'FREQ=MONTHLY;BYMONTHDAY=23', description: 'Celebrate our monthsary every 23rd. This event follows Philippine time (Asia/Manila). November 23 is also our anniversary.' },
      { uid: 'anniversary-november-23', summary: 'Our anniversary', rule: 'FREQ=YEARLY;BYMONTH=11;BYMONTHDAY=23', description: 'Our first anniversary is November 23, 2026. Celebrate every November 23 in Philippine time (Asia/Manila).' }
    ];
    for (const event of events) lines.push('BEGIN:VEVENT', 'UID:' + event.uid + '@beby-leplep.local', 'DTSTAMP:' + stamp, 'DTSTART;TZID=' + TIME_ZONE + ':' + start, 'DURATION:PT30M', 'RRULE:' + event.rule, 'SUMMARY:' + event.summary, 'DESCRIPTION:' + escapeCalendarText(event.description), 'BEGIN:VALARM', 'ACTION:DISPLAY', 'TRIGGER:PT0S', 'DESCRIPTION:' + event.summary, 'END:VALARM', 'END:VEVENT');
    lines.push('END:VCALENDAR');
    // All generated calendar text is ASCII; fold content lines to the RFC's 75-octet limit.
    return lines.map(line => { const folded = []; while (line.length > 75) { folded.push(line.slice(0, 75)); line = ' ' + line.slice(75); } folded.push(line); return folded.join('\r\n'); }).join('\r\n') + '\r\n';
  }
  window.AnniDates = Object.freeze({ timeZone: TIME_ZONE, firstAnniversary: FIRST_ANNIVERSARY, manilaParts, dateKey, celebrationForDay, nextMonthsary, nextAnniversary, daysUntil, reminderFor, makeCalendar });

  const settingsKey = 'anni-keepsakes-v1-reminder-settings';
  const notifiedKey = 'anni-keepsakes-v1-last-celebration-notified';
  let settings = { enabled: false, time: '09:00' };
  try { const saved = JSON.parse(localStorage.getItem(settingsKey)); if (saved && validTime(saved.time)) settings = { enabled: saved.enabled === true, time: saved.time }; } catch { /* Defaults work for this visit. */ }
  function status(message) { $('reminder-status').textContent = message; }
  function saveSettings() {
    try { localStorage.setItem(settingsKey, JSON.stringify(settings)); return true; }
    catch { status('This browser could not save the reminder setting. It will apply for this visit.'); return false; }
  }
  const nativeAlerts = window.AnniNative?.isNative ? window.AnniNative : null;
  let nativePermissionGranted = false;
  let nativeReminderBusy = false;
  let nativeSyncSerial = 0;
  const canUseBrowserAlerts = !nativeAlerts && 'Notification' in window && window.isSecureContext && (location.protocol === 'https:' || ['localhost', '127.0.0.1', '[::1]'].includes(location.hostname));
  function timeLabel(value) {
    const [hour, minute] = value.split(':').map(Number);
    return (hour % 12 || 12) + ':' + pad(minute) + (hour < 12 ? ' AM' : ' PM');
  }
  function reminderButtonState() {
    const active = nativeAlerts ? settings.enabled && nativePermissionGranted : canUseBrowserAlerts && settings.enabled && Notification.permission === 'granted';
    $('enable-reminders').setAttribute('aria-pressed', String(active));
    $('enable-reminders').disabled = nativeAlerts ? nativeReminderBusy : !canUseBrowserAlerts;
    if (nativeAlerts) $('reminder-time').disabled = nativeReminderBusy;
    $('reminder-button-label').textContent = nativeAlerts ? (active ? 'Turn off app reminders' : 'Enable app reminders') : (active ? 'Turn off browser reminders' : 'Enable browser reminders');
  }
  async function syncNativeReminders() {
    if (!nativeAlerts || nativeReminderBusy) return;
    const serial = ++nativeSyncSerial;
    try {
      const permission = await nativeAlerts.checkReminderPermission();
      if (serial !== nativeSyncSerial) return;
      nativePermissionGranted = permission.granted;
      if (settings.enabled && permission.granted) {
        const result = await nativeAlerts.rescheduleReminders(settings.time);
        if (serial !== nativeSyncSerial) return;
        nativePermissionGranted = result.granted;
        if (!result.granted) { status('Allow notifications for Our Journey in Android settings, or tap Enable app reminders.'); return; }
        status('App reminders are on for ' + timeLabel(settings.time) + ' Philippine time, even when the app is closed. Android may delay alerts to save battery.');
      } else if (settings.enabled) status('Allow notifications for Our Journey in Android settings, or tap Enable app reminders.');
      else status('Turn on app reminders for every 23rd and every November 23. You can also save these dates to your calendar.');
    } catch { if (serial === nativeSyncSerial) status('App reminders could not be updated. Try enabling them again or use Add to my calendar.'); }
    finally { if (serial === nativeSyncSerial) reminderButtonState(); }
  }
  $('reminder-time').value = settings.time;
  reminderButtonState();
  if (nativeAlerts) syncNativeReminders();
  else if (!canUseBrowserAlerts) status('Browser alerts need a supported browser and the published HTTPS website. You can add the calendar reminders now.');
  else if (settings.enabled && Notification.permission === 'granted') status('Browser reminders are on for ' + timeLabel(settings.time) + ' Philippine time while this page is open.');

  let selected = civilFromInstant(civilInstant(manilaParts()));
  let view = { year: selected.year, month: selected.month };
  let lastTodayKey = '';
  function renderCalendar() {
    const today = manilaParts();
    $('calendar-month').textContent = monthFormatter.format(new Date(Date.UTC(view.year, view.month - 1, 1)));
    const firstWeekday = new Date(Date.UTC(view.year, view.month - 1, 1)).getUTCDay();
    const days = new Date(Date.UTC(view.year, view.month, 0)).getUTCDate();
    const rows = [];
    let day = 1;
    for (let week = 0; day <= days; week++) {
      const row = document.createElement('tr');
      for (let weekday = 0; weekday < 7; weekday++) {
        const cell = document.createElement('td');
        if (week === 0 && weekday < firstWeekday || day > days) { cell.setAttribute('aria-hidden', 'true'); row.append(cell); continue; }
        const date = { year: view.year, month: view.month, day };
        const key = dateKey(date);
        const celebration = celebrationForDay(date);
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'calendar-day';
        button.dataset.date = key;
        button.textContent = day;
        button.tabIndex = key === dateKey(selected) ? 0 : -1;
        button.setAttribute('aria-pressed', String(key === dateKey(selected)));
        button.setAttribute('aria-label', fullCivilFormatter.format(civilInstant(date)) + (celebration ? ' - ' + celebration.detail : ''));
        if (key === dateKey(selected)) button.classList.add('is-selected');
        if (key === dateKey(today)) { button.classList.add('is-today'); button.setAttribute('aria-current', 'date'); }
        if (celebration) button.classList.add('monthsary-day');
        if (celebration?.kind === 'anniversary') button.classList.add('anniversary-day');
        cell.append(button); row.append(cell); day++;
      }
      rows.push(row);
    }
    $('calendar-days').replaceChildren(...rows);
    const occasion = celebrationForDay(selected);
    $('calendar-selection').textContent = civilFormatter.format(civilInstant(selected)) + ' - ' + (occasion ? occasion.detail + ' ♡' : 'A little more time for us.');
  }
  function focusSelectedDay() { $('calendar-days').querySelector('[data-date="' + dateKey(selected) + '"]')?.focus(); }
  function changeMonth(delta, focus = false) {
    const month = new Date(Date.UTC(view.year, view.month - 1 + delta, 1));
    view = { year: month.getUTCFullYear(), month: month.getUTCMonth() + 1 };
    selected = { ...view, day: Math.min(selected.day, new Date(Date.UTC(view.year, view.month, 0)).getUTCDate()) };
    renderCalendar();
    if (focus) focusSelectedDay();
  }
  $('calendar-previous').addEventListener('click', () => changeMonth(-1));
  $('calendar-next').addEventListener('click', () => changeMonth(1));
  $('calendar-today').addEventListener('click', () => { selected = civilFromInstant(civilInstant(manilaParts())); view = { year: selected.year, month: selected.month }; renderCalendar(); focusSelectedDay(); });
  $('calendar-days').addEventListener('click', event => {
    const button = event.target.closest('button[data-date]');
    if (!button) return;
    const [year, month, day] = button.dataset.date.split('-').map(Number);
    selected = { year, month, day }; renderCalendar(); focusSelectedDay();
  });
  $('calendar-days').addEventListener('keydown', event => {
    if (!event.target.closest('button[data-date]')) return;
    const weekday = civilInstant(selected).getUTCDay();
    const delta = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -7, ArrowDown: 7, Home: -weekday, End: 6 - weekday }[event.key];
    if (event.key === 'PageUp' || event.key === 'PageDown') { event.preventDefault(); changeMonth(event.key === 'PageUp' ? -1 : 1, true); return; }
    if (delta === undefined) return;
    event.preventDefault();
    selected = civilFromInstant(new Date(Date.UTC(selected.year, selected.month - 1, selected.day + delta)));
    view = { year: selected.year, month: selected.month };
    renderCalendar(); focusSelectedDay();
  });
  function updateClock(instant = new Date()) {
    const today = manilaParts(instant);
    const key = dateKey(today);
    $('ph-clock').textContent = clockFormatter.format(instant);
    $('ph-clock').dateTime = instant.toISOString();
    $('ph-date').textContent = dateFormatter.format(instant);
    $('ph-date').dateTime = key;
    if (key === lastTodayKey) return;
    if (lastTodayKey && dateKey(selected) === lastTodayKey) { selected = { year: today.year, month: today.month, day: today.day }; view = { year: today.year, month: today.month }; }
    lastTodayKey = key;
    const monthly = nextMonthsary(instant), annual = nextAnniversary(instant);
    const countdown = date => { const days = daysUntil(date, instant); return days === 0 ? 'Today is our special day ♡' : days === 1 ? 'Tomorrow ♡' : days + ' days to go'; };
    $('next-monthsary').textContent = civilFormatter.format(civilInstant(monthly));
    $('monthsary-countdown').textContent = countdown(monthly);
    $('next-anniversary-label').textContent = ordinal(annual.year - FIRST_ANNIVERSARY.year + 1) + ' anniversary';
    $('next-anniversary').textContent = civilFormatter.format(civilInstant(annual));
    $('anniversary-countdown').textContent = countdown(annual);
    const celebration = celebrationForDay(today);
    $('today-celebration').hidden = !celebration;
    $('today-celebration').textContent = celebration ? celebration.title + ' ♡' : '';
    renderCalendar();
  }

  let registrationPromise;
  async function notificationRegistration() {
    if (!('serviceWorker' in navigator)) return null;
    if (!registrationPromise) {
      registrationPromise = (async () => {
        await navigator.serviceWorker.register('./anniversary-sw.js', { updateViaCache: 'none' });
        return await new Promise((resolve, reject) => {
          const timer = setTimeout(() => reject(new Error('Reminder worker did not activate')), 8000);
          navigator.serviceWorker.ready.then(registration => { clearTimeout(timer); resolve(registration); }, reject);
        });
      })().catch(error => { registrationPromise = null; throw error; });
    }
    return registrationPromise;
  }
  async function showBrowserNotification(title, body, tag) {
    const options = { body, tag, icon: new URL('assets/cinnamoroll-envelope-3d.png', location.href).href, data: { url: new URL('./', location.href).href } };
    const registration = await notificationRegistration();
    if (registration) await registration.showNotification(title, options);
    else {
      const notification = new Notification(title, options);
      notification.onclick = () => { window.focus(); notification.close(); };
    }
  }
  const sessionNotified = new Set();
  let reminderBusy = false;
  async function checkReminders(instant = new Date()) {
    if (document.documentElement.classList.contains('welcome-active')) return;
    if (nativeAlerts) return;
    if (!canUseBrowserAlerts || !settings.enabled || Notification.permission !== 'granted' || reminderBusy) return;
    let last = '';
    try { last = localStorage.getItem(notifiedKey) || ''; } catch { /* Session-only deduplication still works. */ }
    const occasion = reminderFor(instant, settings.time, last);
    if (!occasion || sessionNotified.has(occasion.date)) return;
    reminderBusy = true;
    try {
      await showBrowserNotification(occasion.title, occasion.kind === 'anniversary' ? 'It is November 23 in the Philippines - our anniversary and monthsary. Here is to more sweet years together!' : 'It is the 23rd in the Philippines. A little celebration for the two of us!', 'anni-celebration-' + occasion.date);
      sessionNotified.add(occasion.date);
      try { localStorage.setItem(notifiedKey, occasion.date); } catch { /* Do not repeat within this visit. */ }
    } catch { status('The browser could not show a reminder. Check notification permissions and use the calendar download for alerts when the page is closed.'); }
    finally { reminderBusy = false; }
  }
  $('enable-reminders').addEventListener('click', async () => {
    if (nativeAlerts) {
      if (nativeReminderBusy) return;
      nativeSyncSerial++;
      nativeReminderBusy = true;
      reminderButtonState();
      try {
        if (settings.enabled && nativePermissionGranted) {
          await nativeAlerts.disableReminders();
          settings.enabled = false;
          saveSettings();
          status('App reminders turned off. Imported calendar alerts are managed in your calendar app.');
        } else {
          const result = await nativeAlerts.enableReminders(settings.time);
          nativePermissionGranted = result.granted;
          if (!result.granted) { status('Notifications were not enabled. Allow them for Our Journey in Android settings, or use Add to my calendar.'); return; }
          settings.enabled = true;
          saveSettings();
          status('App reminders are on for ' + timeLabel(settings.time) + ' Philippine time, even when the app is closed. Android may delay alerts to save battery.');
        }
      } catch { status('App reminders could not be changed. Try again, or add these dates to your calendar.'); }
      finally { nativeReminderBusy = false; reminderButtonState(); }
      return;
    }
    if (settings.enabled && Notification.permission === 'granted') {
      settings.enabled = false; saveSettings(); reminderButtonState();
      status('Browser reminders turned off. Imported calendar alerts are managed in your calendar app.');
      return;
    }
    $('enable-reminders').disabled = true;
    try {
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') { status('Notifications were not enabled. You can allow them in your browser settings or use Add to my calendar.'); return; }
      await showBrowserNotification('Our special dates are ready ♡', 'Reminders on every 23rd and every November 23 at ' + timeLabel(settings.time) + ' Philippine time while this page is open.', 'anni-reminders-ready');
      settings.enabled = true;
      const saved = saveSettings();
      if (saved) status('Browser reminders are on for ' + timeLabel(settings.time) + ' Philippine time. Add these dates to your calendar for alerts when the page is closed.');
      await checkReminders();
    } catch { settings.enabled = false; saveSettings(); status('This browser could not enable reminders here. Use Add to my calendar, or try the published website in a supported browser.'); }
    finally { reminderButtonState(); }
  });
  $('reminder-time').addEventListener('change', event => {
    if (!validTime(event.target.value)) { event.target.value = settings.time; return; }
    settings.time = event.target.value;
    const saved = saveSettings();
    if (nativeAlerts) { syncNativeReminders(); return; }
    if (saved) status('Reminder time saved: ' + timeLabel(settings.time) + ' Philippine time. If you already imported the calendar, update those events or import a new download.');
    checkReminders();
  });
  $('download-calendar').addEventListener('click', async () => {
    if (nativeAlerts) {
      const button = $('download-calendar');
      button.disabled = true;
      try {
        const result = await nativeAlerts.exportCalendar(makeCalendar(settings.time));
        status(result.cancelled ? 'Calendar sharing cancelled. Your special dates are still here.' : 'Choose an app that can save or import the shared calendar file. Enable its event alerts for your special dates.');
      } catch { status('The calendar file could not be shared. Please try again.'); }
      finally { button.disabled = false; }
      return;
    }
    const url = URL.createObjectURL(new Blob([makeCalendar(settings.time)], { type: 'text/calendar;charset=utf-8' }));
    const link = document.createElement('a');
    link.href = url; link.download = 'our-monthsaries-and-anniversaries.ics';
    document.body.append(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
    status('Open the downloaded calendar file and import both recurring events. Check that event alerts are enabled at ' + timeLabel(settings.time) + ' Philippine time in your calendar app.');
  });
  let clockTimer, reminderTimer;
  function startTimers() {
    clearInterval(clockTimer); clearInterval(reminderTimer);
    updateClock(); checkReminders();
    clockTimer = setInterval(() => { if (!document.hidden) updateClock(); }, 1000);
    reminderTimer = setInterval(() => checkReminders(), 30000);
  }
  document.addEventListener('visibilitychange', () => { if (!document.hidden) { updateClock(); checkReminders(); reminderButtonState(); } });
  document.addEventListener('anni:entered', () => { updateClock(); checkReminders(); reminderButtonState(); });
  document.addEventListener('anni:native-resume', () => { updateClock(); syncNativeReminders(); });
  window.addEventListener('pageshow', startTimers);
  window.addEventListener('pagehide', () => { clearInterval(clockTimer); clearInterval(reminderTimer); });
  startTimers();
})();
