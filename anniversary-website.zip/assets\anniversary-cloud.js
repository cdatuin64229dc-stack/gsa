(() => {
  'use strict';

  const settingsKey = 'our-journey-shared-album-v1';
  let baseUrl = 'https://our-journey-album-leplep-8q3n.equalcow13.chatgpt.site';
  let setupUrl = 'https://our-journey-album-leplep-8q3n.equalcow13.chatgpt.site/setup';
  const maxBytes = 20 * 1024 * 1024;
  const imageTypes = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif', 'image/heic', 'image/heif']);
  let code = '';
  let fingerprint = '';
  let records = [];
  let connected = false;
  let online = false;
  let cacheHealthy = true;
  let queue = Promise.resolve();
  let cacheDatabase;

  class CloudError extends Error {
    constructor(message, status = 0) { super(message); this.name = 'CloudError'; this.status = status; }
  }
  function serialize(operation) {
    const result = queue.then(operation, operation);
    queue = result.catch(() => {});
    return result;
  }
  function savedSettings() {
    try {
      const saved = JSON.parse(localStorage.getItem(settingsKey));
      return saved && saved.baseUrl === baseUrl && typeof saved.code === 'string' ? saved : null;
    } catch { return null; }
  }
  function saveConnection(value) {
    try {
      if (value) localStorage.setItem(settingsKey, JSON.stringify({ baseUrl, code: value }));
      else localStorage.removeItem(settingsKey);
    } catch { /* The connection remains available for this visit. */ }
  }
  function cleanCode(value) {
    const result = typeof value === 'string' ? value.trim() : '';
    if (!/^[A-Za-z0-9_-]{16,128}$/.test(result)) throw new CloudError('Paste the complete shared album code.');
    return result;
  }
  async function makeFingerprint(value) {
    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(baseUrl + '\n' + value));
    return [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('');
  }
  function metadata(value) {
    if (!value || typeof value.id !== 'string' || !/^[A-Za-z0-9_-]{1,100}$/.test(value.id) || !Number.isInteger(value.slot) || value.slot < 0 || value.slot >= 24 || !Number.isInteger(value.revision) || value.revision < 1 || typeof value.caption !== 'string' || value.caption.length > 60 || !imageTypes.has(value.contentType) || !Number.isFinite(value.size) || value.size < 1 || value.size > maxBytes) {
      throw new CloudError('The shared album returned an unreadable photo. Try refreshing again.');
    }
    return { id: value.id, slot: value.slot, caption: value.caption, revision: value.revision, contentType: value.contentType, size: value.size, updatedAt: value.updatedAt };
  }
  function copyRecords(values = records) { return values.map(item => ({ ...item })); }
  function db() {
    if (cacheDatabase) return cacheDatabase;
    cacheDatabase = new Promise(resolve => {
      if (!window.indexedDB) { resolve(null); return; }
      let done = false;
      const finish = value => { if (done) { value?.close(); return; } done = true; clearTimeout(timer); resolve(value); };
      const timer = setTimeout(() => finish(null), 4000);
      try {
        const request = indexedDB.open('our-journey-shared-cache-v1', 1);
        request.onupgradeneeded = () => request.result.createObjectStore('albums', { keyPath: 'key' });
        request.onsuccess = () => finish(request.result);
        request.onerror = request.onblocked = () => finish(null);
      } catch { finish(null); }
    });
    return cacheDatabase;
  }
  async function readCache(key) {
    const database = await db();
    if (!database) return null;
    return new Promise(resolve => {
      try {
        const transaction = database.transaction('albums', 'readonly');
        const request = transaction.objectStore('albums').get(key);
        request.onsuccess = () => {
          try {
            const cached = request.result;
            if (!cached || !Array.isArray(cached.photos) || cached.photos.length > 24) { resolve(null); return; }
            const photos = cached.photos.map(item => ({ ...metadata(item), blob: item.blob }));
            if (photos.some(item => !(item.blob instanceof Blob) || item.blob.size !== item.size || item.blob.type !== item.contentType) || new Set(photos.map(item => item.slot)).size !== photos.length || new Set(photos.map(item => item.id)).size !== photos.length) { resolve(null); return; }
            resolve(photos);
          } catch { resolve(null); }
        };
        request.onerror = () => resolve(null);
      } catch { resolve(null); }
    });
  }
  async function writeCache(key, photos) {
    const database = await db();
    if (!database) { cacheHealthy = false; return; }
    try {
      await new Promise((resolve, reject) => {
        const transaction = database.transaction('albums', 'readwrite');
        transaction.objectStore('albums').put({ key, photos: copyRecords(photos) });
        transaction.oncomplete = resolve;
        transaction.onerror = transaction.onabort = () => reject(transaction.error);
      });
      cacheHealthy = true;
    } catch { cacheHealthy = false; }
  }
  async function request(path, options = {}, authCode = code, blob = false) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 35000);
    try {
      const response = await fetch(baseUrl + path, {
        ...options,
        headers: { ...options.headers, Authorization: 'Bearer ' + authCode },
        credentials: 'omit', cache: 'no-store', redirect: 'error', signal: controller.signal
      });
      if (!response.ok) {
        if (response.status === 401 || response.status === 403) { online = false; throw new CloudError('The album code was not accepted. Check your code and connect again.', response.status); }
        if (response.status === 409) throw new CloudError('The album changed on another device. Refresh it, then try again.', 409);
        if (response.status === 404 && blob) throw new CloudError('A photo changed on another device. Refresh the album, then try again.', 409);
        if (response.status === 413) throw new CloudError('Choose a photo smaller than 20 MB.', 413);
        if (response.status === 415) throw new CloudError('Use a JPEG, PNG, WebP, GIF, or AVIF photo.', 415);
        if (response.status === 507) throw new CloudError('This shared album is full. Remove a photo before adding another.', 507);
        throw new CloudError(!options.method || options.method === 'GET' ? 'The shared album could not be loaded. Please try Refresh again.' : 'The shared album could not save that change. Please try again.', response.status);
      }
      online = true;
      if (response.status === 204) return null;
      if (blob) {
        const result = await response.blob();
        if (!imageTypes.has(result.type) || result.size < 1 || result.size > maxBytes) throw new CloudError('A shared photo could not be opened. Please refresh again.');
        return result;
      }
      return await response.json();
    } catch (error) {
      if (error instanceof CloudError) throw error;
      online = false;
      throw new CloudError('The shared album could not be reached. Check your internet connection and try Refresh.');
    } finally { clearTimeout(timer); }
  }
  async function fetchSnapshot(authCode, previous = [], retries = 1) {
    try {
    const result = await request('/api/album', {}, authCode);
    if (!result || !Array.isArray(result.photos) || result.photos.length > 24) throw new CloudError('The shared album could not be opened. Please refresh again.');
    const items = result.photos.map(metadata);
    if (new Set(items.map(item => item.slot)).size !== items.length || new Set(items.map(item => item.id)).size !== items.length) throw new CloudError('The shared album returned overlapping photos. Please refresh again.');
    const next = [];
    // Two downloads at a time keeps large photo albums gentle on a phone's memory.
    let position = 0;
    const downloads = await Promise.allSettled(Array.from({ length: Math.min(2, items.length) }, async () => {
      while (position < items.length) {
        const item = items[position++];
        const cached = previous.find(old => old.id === item.id && old.revision === item.revision && old.blob instanceof Blob);
        const photoBlob = cached?.blob || await request('/api/album/photos/' + encodeURIComponent(item.id) + '/content', { headers: { 'If-Match': String(item.revision) } }, authCode, true);
        if (photoBlob.size !== item.size || photoBlob.type !== item.contentType) throw new CloudError('A shared photo changed while loading. Please refresh the album again.');
        next.push({ ...item, blob: photoBlob });
      }
    }));
    const failed = downloads.find(result => result.status === 'rejected');
    if (failed) throw failed.reason;
    return next.sort((a, b) => a.slot - b.slot);
    } catch (error) {
      if (error.status === 409 && retries > 0) return fetchSnapshot(authCode, previous, retries - 1);
      if (error.status !== 409) online = false;
      throw error;
    }
  }
  async function commit(next) {
    await writeCache(fingerprint, next);
    records = next;
    return copyRecords();
  }
  function requireConnection() {
    if (!connected) throw new CloudError('Connect your shared album first.');
    if (navigator.onLine === false || !online) throw new CloudError('You are viewing a saved copy. Connect to the internet and Refresh before making changes.');
  }
  function form(photo, caption) {
    if (!(photo instanceof Blob) || !imageTypes.has(photo.type) || photo.size < 1 || photo.size > maxBytes) throw new CloudError('Use a supported photo smaller than 20 MB.');
    const body = new FormData();
    body.append('photo', photo, photo.name || 'memory.' + (photo.type.split('/')[1] || 'jpg'));
    body.append('caption', String(caption || '').trim().slice(0, 60));
    return body;
  }
  function uploadId() {
    if (crypto.randomUUID) return crypto.randomUUID();
    const bytes = crypto.getRandomValues(new Uint8Array(16));
    bytes[6] = bytes[6] & 15 | 64;
    bytes[8] = bytes[8] & 63 | 128;
    const hex = [...bytes].map(value => value.toString(16).padStart(2, '0')).join('');
    return [hex.slice(0, 8), hex.slice(8, 12), hex.slice(12, 16), hex.slice(16, 20), hex.slice(20)].join('-');
  }

  window.AnniCloud = Object.freeze({
    configure(configuration) {
      if (connected) throw new CloudError('Disconnect the current album before changing its connection.');
      if (configuration.baseUrl) {
        const value = new URL(configuration.baseUrl);
        if (value.protocol !== 'https:' && !['127.0.0.1', 'localhost'].includes(value.hostname)) throw new CloudError('The album needs a secure connection.');
        baseUrl = value.origin;
      }
      if (configuration.setupUrl) setupUrl = String(configuration.setupUrl);
    },
    get connected() { return connected; },
    get online() { return online; },
    get cacheHealthy() { return cacheHealthy; },
    get savedCode() { return savedSettings()?.code || ''; },
    get setupUrl() { return setupUrl; },
    snapshot: () => copyRecords(),
    connect(value) {
      return serialize(async () => {
        const nextCode = cleanCode(value);
        const nextFingerprint = await makeFingerprint(nextCode);
        const cached = await readCache(nextFingerprint);
        const next = await fetchSnapshot(nextCode, cached || []);
        code = nextCode; fingerprint = nextFingerprint; connected = true;
        await commit(next);
        saveConnection(code);
        return { photos: copyRecords(), offline: false };
      });
    },
    restore() {
      return serialize(async () => {
        const saved = savedSettings();
        if (!saved) return { connected: false };
        const nextCode = cleanCode(saved.code);
        const nextFingerprint = await makeFingerprint(nextCode);
        const cached = await readCache(nextFingerprint);
        let next;
        try { next = await fetchSnapshot(nextCode, cached || []); }
        catch (error) {
          if (cached === null) throw error;
          next = cached; online = false;
        }
        code = nextCode; fingerprint = nextFingerprint; connected = true;
        if (online) await commit(next); else records = next;
        return { connected: true, photos: copyRecords(), offline: !online };
      });
    },
    disconnect() {
      return serialize(async () => {
        connected = false; online = false; code = ''; fingerprint = ''; records = [];
        saveConnection('');
      });
    },
    refresh() {
      return serialize(async () => {
        if (!connected) throw new CloudError('Connect your shared album first.');
        const next = await fetchSnapshot(code, records);
        return commit(next);
      });
    },
    add(photo, caption = '') {
      return serialize(async () => {
        requireConnection();
        const result = await request('/api/album/photos', { method: 'POST', headers: { 'X-Upload-Id': uploadId() }, body: form(photo, caption) });
        const item = { ...metadata(result?.photo), blob: photo };
        await commit([...records.filter(old => old.slot !== item.slot && old.id !== item.id), item].sort((a, b) => a.slot - b.slot));
        return { ...item };
      });
    },
    replace(item, photo, caption = item.caption) {
      return serialize(async () => {
        requireConnection();
        const result = await request('/api/album/photos/' + encodeURIComponent(item.id), { method: 'PUT', headers: { 'If-Match': String(item.revision) }, body: form(photo, caption) });
        const replacement = { ...metadata(result?.photo), blob: photo };
        await commit(records.map(old => old.id === item.id ? replacement : old));
        return { ...replacement };
      });
    },
    updateCaption(item, caption) {
      return serialize(async () => {
        requireConnection();
        const result = await request('/api/album/photos/' + encodeURIComponent(item.id), { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ caption, expectedRevision: item.revision }) });
        const replacement = { ...metadata(result?.photo), blob: item.blob };
        await commit(records.map(old => old.id === item.id ? replacement : old));
        return { ...replacement };
      });
    },
    remove(item) {
      return serialize(async () => {
        requireConnection();
        await request('/api/album/photos/' + encodeURIComponent(item.id), { method: 'DELETE', headers: { 'If-Match': String(item.revision) } });
        await commit(records.filter(old => old.id !== item.id));
      });
    }
  });
})();
