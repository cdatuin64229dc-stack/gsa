(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  function focusIfVisible(control) {
    if (control?.getClientRects().length && !control.closest('[inert]')) control.focus();
  }
  const prefix = 'anni-keepsakes-v1-';
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  let toastTimer;
  function announce(message) {
    clearTimeout(toastTimer);
    const target = document.querySelector('dialog[open] .dialog-status') || $('toast');
    for (const status of document.querySelectorAll('.dialog-status, #toast')) status.textContent = '';
    target.textContent = message;
    toastTimer = setTimeout(() => { target.textContent = ''; }, 5500);
  }
  function readSaved(key, fallback) {
    try { return JSON.parse(localStorage.getItem(prefix + key)) ?? fallback; }
    catch { return fallback; }
  }
  function save(key, value) {
    try { localStorage.setItem(prefix + key, JSON.stringify(value)); return true; }
    catch { announce('Kept for this visit. This browser could not save your changes.'); return false; }
  }

  // Dialogs retain the browser's native focus trap, Escape key and focus return.
  function openDialog(dialog) {
    dialog.showModal();
    document.documentElement.classList.add('dialog-open');
  }
  for (const button of document.querySelectorAll('[data-close]')) {
    button.addEventListener('click', () => $(button.dataset.close).close());
  }
  for (const dialog of document.querySelectorAll('dialog')) {
    dialog.addEventListener('close', () => {
      if (!document.querySelector('dialog[open]')) document.documentElement.classList.remove('dialog-open');
    });
    dialog.addEventListener('click', (event) => {
      if (event.target !== dialog) return;
      const bounds = dialog.getBoundingClientRect();
      if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) dialog.close();
    });
  }

  const defaultLetter = `My beby,

A whole year of us, and you are still my favorite person.

Thank you for the laughter, the little moments, and the love we keep choosing. Life feels sweeter with you in it.

I hope our next chapter holds more adventures, more quiet days together, and a thousand little reasons to smile.

Happy 1st anniversary. Here's to many more sweet years of us.

Always yours ♡`;
  const storedLetter = readSaved('letter', defaultLetter);
  let letter = typeof storedLetter === 'string' && storedLetter.trim() ? storedLetter.slice(0, 6000) : defaultLetter;
  $('letter-copy').textContent = letter;
  function stopEditingLetter() {
    $('letter-text').setCustomValidity('');
    $('letter-form').hidden = true;
    $('letter-copy').hidden = false;
    $('edit-letter').hidden = false;
  }
  function openLetter() {
    if (window.AnniPages?.goTo) {
      window.AnniPages.goTo('love-letter');
      return;
    }
    const dialog = $('letter-dialog');
    if (typeof dialog?.showModal === 'function') {
      openDialog(dialog);
      return;
    }
    const page = $('love-letter');
    if (!page) return;
    page.hidden = false;
    page.scrollIntoView({ block: 'start', behavior: 'auto' });
    const heading = $('letter-title');
    if (heading) heading.tabIndex = -1;
    focusIfVisible(heading);
  }
  for (const id of ['open-letter', 'letter-hint']) {
    $(id)?.addEventListener('click', openLetter);
  }
  // The screen navigator owns category links; older standalone copies use this fallback.
  if (!window.AnniPages) $('letter-nav')?.addEventListener('click', openLetter);
  $('edit-letter').addEventListener('click', () => {
    $('letter-text').value = letter;
    $('letter-form').hidden = false;
    $('letter-copy').hidden = true;
    $('edit-letter').hidden = true;
    $('letter-text').focus();
  });
  $('cancel-letter').addEventListener('click', () => { stopEditingLetter(); $('edit-letter').focus(); });
  $('letter-form').addEventListener('submit', (event) => {
    event.preventDefault();
    const value = $('letter-text').value.trim();
    if (!value) { $('letter-text').setCustomValidity('Write a little something from the heart.'); $('letter-text').reportValidity(); return; }
    letter = value;
    $('letter-copy').textContent = letter;
    const saved = save('letter', letter);
    stopEditingLetter();
    $('edit-letter').focus();
    if (saved) announce('Your letter is saved on this device. ♡');
  });
  $('letter-text').addEventListener('input', () => $('letter-text').setCustomValidity(''));

  $('hug-button').addEventListener('click', () => {
    announce('A big, warm hug, just for you. ♡');
    if (reducedMotion.matches) return;
    const bounds = $('hug-button').getBoundingClientRect();
    const layer = $('heart-burst');
    for (let index = 0; index < 18; index++) {
      const heart = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      const symbol = document.createElementNS('http://www.w3.org/2000/svg', 'use');
      symbol.setAttribute('href', '#puffy-heart');
      heart.append(symbol);
      heart.setAttribute('viewBox', '0 0 40 40');
      heart.classList.add('flying-heart');
      heart.style.left = `${bounds.left + bounds.width / 2 - 14}px`;
      heart.style.top = `${bounds.top + bounds.height / 2 - 14}px`;
      heart.style.setProperty('--size', `${18 + Math.random() * 22}px`);
      heart.style.setProperty('--drift', `${(Math.random() - .5) * 320}px`);
      heart.style.setProperty('--turn', `${(Math.random() - .5) * 110}deg`);
      heart.style.animationDelay = `${Math.random() * .25}s`;
      layer.append(heart);
      setTimeout(() => heart.remove(), 2900);
    }
    while (layer.children.length > 60) layer.firstElementChild.remove();
  });

  // The hit area stays still while the artwork floats. Click also supports touch and keyboard.
  const companion = $('cloud-companion');
  const cloudMessages = ['A little cloud hug for you. ♡', 'You make my sky brighter. ♡', 'Floating by with love. ♡'];
  let cloudVisits = 0;
  let companionReactionTimer;
  let companionMessageTimer;
  companion.addEventListener('click', () => {
    const message = cloudMessages[cloudVisits++ % cloudMessages.length];
    const bubble = $('companion-message');
    bubble.textContent = message;
    bubble.hidden = false;
    $('companion-feedback').textContent = message;
    clearTimeout(companionMessageTimer);
    companionMessageTimer = setTimeout(() => { bubble.hidden = true; $('companion-feedback').textContent = ''; }, 3400);
    clearTimeout(companionReactionTimer);
    companion.classList.remove('is-delighted');
    void companion.offsetWidth;
    companion.classList.add('is-delighted');
    companionReactionTimer = setTimeout(() => companion.classList.remove('is-delighted'), 950);
    if (reducedMotion.matches) return;
    const bounds = companion.getBoundingClientRect();
    const layer = $('heart-burst');
    for (let index = 0; index < 16; index++) {
      const particle = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      const symbol = document.createElementNS('http://www.w3.org/2000/svg', 'use');
      symbol.setAttribute('href', index % 3 === 0 ? '#puffy-heart' : index % 2 === 0 ? '#puffy-star' : '#puffy-white-star');
      particle.append(symbol);
      particle.setAttribute('viewBox', '0 0 40 40');
      particle.setAttribute('focusable', 'false');
      particle.classList.add('cloud-magic-particle');
      particle.style.left = (bounds.left + bounds.width / 2) + 'px';
      particle.style.top = (bounds.top + bounds.height * .45) + 'px';
      const angle = (Math.PI * 2 * index) / 16;
      const distance = 55 + Math.random() * 70;
      particle.style.setProperty('--size', (14 + Math.random() * 16) + 'px');
      particle.style.setProperty('--drift-x', Math.cos(angle) * distance + 'px');
      particle.style.setProperty('--drift-y', (Math.sin(angle) * distance - 30) + 'px');
      particle.style.setProperty('--turn', ((Math.random() - .5) * 130) + 'deg');
      layer.append(particle);
      setTimeout(() => particle.remove(), 1650);
    }
    const particles = layer.querySelectorAll('.cloud-magic-particle');
    for (let index = 0; index < particles.length - 48; index++) particles[index].remove();
  });

  // An original little music-box waltz: a bell melody over a soft, bouncing accompaniment.
  // Everything is synthesized locally and starts only when Play is pressed.
  let audioContext;
  let master;
  let musicTimer;
  let nextBeat = 0;
  let step = 0;
  let playing = false;
  let musicSession = 0;
  const voices = new Set();
  const eighthNote = 60 / 104 / 2;
  // Six eighth-note positions per bar. Zero leaves space for the previous bell to ring.
  const melody = [
    [76, 79, 76, 0, 74, 76], [72, 0, 76, 79, 81, 0],
    [81, 79, 77, 0, 76, 0], [74, 0, 79, 0, 0, 0],
    [76, 79, 84, 0, 83, 81], [79, 76, 72, 0, 76, 0],
    [77, 76, 74, 0, 77, 81], [79, 0, 0, 74, 71, 0],
    [76, 0, 79, 76, 74, 0], [76, 79, 83, 0, 79, 0],
    [81, 0, 79, 77, 76, 0], [79, 76, 74, 0, 0, 0],
    [77, 81, 84, 0, 81, 77], [79, 81, 83, 0, 79, 0],
    [76, 0, 74, 76, 79, 0], [72, 0, 0, 0, 0, 0]
  ];
  // Bass, then two quiet harmony notes on the second and third beats of each bar.
  const harmony = [
    [48, 64, 67], [45, 60, 64], [41, 60, 65], [43, 59, 65],
    [48, 64, 67], [45, 60, 64], [50, 62, 65], [43, 59, 65],
    [48, 64, 67], [40, 59, 64], [41, 60, 65], [43, 60, 64],
    [50, 60, 65], [43, 59, 65], [48, 64, 67], [48, 64, 67]
  ];
  function musicState() {
    $('music-button').setAttribute('aria-pressed', String(playing));
    $('music-label').textContent = playing ? 'Pause music' : 'Play cute music';
  }
  function stopVoice(voice) {
    if (!voices.delete(voice)) return;
    for (const { oscillator, level } of voice.nodes) {
      oscillator.onended = null;
      try { oscillator.stop(); } catch { /* Already ended. */ }
      oscillator.disconnect();
      level.disconnect();
    }
    voice.gain.disconnect();
  }
  function chime(note, time, volume = .14, duration = 1.3, bright = true) {
    const frequency = 440 * Math.pow(2, (note - 69) / 12);
    const gain = audioContext.createGain();
    gain.gain.setValueAtTime(.0001, time);
    gain.gain.exponentialRampToValueAtTime(volume, time + .012);
    gain.gain.exponentialRampToValueAtTime(volume * .38, time + .14);
    gain.gain.exponentialRampToValueAtTime(.0001, time + duration);
    gain.connect(master);
    const voice = { gain, nodes: [] };
    voices.add(voice);
    const partials = bright ? [[1, 1], [2, .12], [3, .025]] : [[1, 1], [2, .04]];
    for (const [harmonic, strength] of partials) {
      const oscillator = audioContext.createOscillator();
      const level = audioContext.createGain();
      oscillator.type = 'sine';
      oscillator.frequency.value = frequency * harmonic;
      level.gain.value = strength;
      oscillator.connect(level).connect(gain);
      voice.nodes.push({ oscillator, level });
      oscillator.onended = () => stopVoice(voice);
      oscillator.start(time);
      oscillator.stop(time + duration + .03);
    }
  }
  function scheduleMusic() {
    // A delayed browser timer must not bunch old notes into one loud chord.
    if (nextBeat < audioContext.currentTime - eighthNote) nextBeat = audioContext.currentTime + .03;
    while (playing && nextBeat < audioContext.currentTime + .2) {
      const bar = Math.floor(step / 6);
      const position = step % 6;
      const note = melody[bar][position];
      if (note) chime(note, nextBeat);
      if (position === 0) chime(harmony[bar][0], nextBeat, .075, .65, false);
      if (position === 2 || position === 4) {
        chime(harmony[bar][1], nextBeat, .035, .55, false);
        chime(harmony[bar][2], nextBeat + .018, .03, .55, false);
      }
      nextBeat += eighthNote;
      step = (step + 1) % (melody.length * 6);
    }
  }
  async function pauseMusic() {
    musicSession++;
    playing = false;
    clearInterval(musicTimer);
    for (const voice of voices) stopVoice(voice);
    musicState();
    if (audioContext?.state === 'running') await audioContext.suspend();
  }
  $('music-button').addEventListener('click', async () => {
    const button = $('music-button');
    button.disabled = true;
    try {
      if (playing) await pauseMusic();
      else {
        const requestedSession = ++musicSession;
        const AudioClass = window.AudioContext || window.webkitAudioContext;
        if (!AudioClass) throw new Error('Web Audio is not available');
        if (!audioContext || audioContext.state === 'closed') {
          audioContext = new AudioClass();
          master = audioContext.createGain();
          master.gain.value = .28;
          master.connect(audioContext.destination);
          audioContext.addEventListener('statechange', () => {
            if (playing && audioContext.state !== 'running') pauseMusic().catch(() => {});
          });
        }
        await audioContext.resume();
        if (requestedSession !== musicSession || document.hidden) {
          if (!playing && audioContext.state === 'running') await audioContext.suspend();
          return;
        }
        if (audioContext.state !== 'running') throw new Error('Audio did not start');
        playing = true;
        step = 0;
        nextBeat = audioContext.currentTime + .06;
        scheduleMusic();
        clearInterval(musicTimer);
        musicTimer = setInterval(scheduleMusic, 100);
        musicState();
      }
    } catch {
      await pauseMusic().catch(() => {});
      announce('Music could not start in this browser. Try pressing Play again.');
    } finally { button.disabled = false; }
  });
  document.addEventListener('visibilitychange', () => { if (document.hidden) pauseMusic().catch(() => {}); });
  window.addEventListener('pagehide', () => { pauseMusic().catch(() => {}); });
  document.addEventListener('anni:native-pause', () => { pauseMusic().catch(() => {}); });

  const defaultWishes = [
    { id: 'slow-day', text: 'A slow day, just you and me', done: false },
    { id: 'adventure', text: 'A new place to explore together', done: false },
    { id: 'little-moments', text: 'More little moments worth remembering', done: false }
  ];
  const savedWishes = readSaved('wishes', defaultWishes);
  let wishes = Array.isArray(savedWishes) ? savedWishes.filter((wish) => wish && typeof wish.id === 'string' && typeof wish.text === 'string' && wish.text.trim()).slice(0, 20).map((wish) => ({ id: wish.id, text: wish.text.slice(0, 100), done: Boolean(wish.done) })) : defaultWishes;
  function renderWishes() {
    $('wish-list').replaceChildren();
    wishes.forEach((wish, index) => {
      const row = document.createElement('li');
      row.className = 'wish-row';
      const label = document.createElement('label');
      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.checked = wish.done;
      const text = document.createElement('span');
      text.textContent = wish.text;
      label.append(checkbox, text);
      const remove = document.createElement('button');
      remove.type = 'button';
      remove.className = 'remove-wish';
      remove.textContent = '×';
      remove.setAttribute('aria-label', `Remove wish: ${wish.text}`);
      checkbox.addEventListener('change', () => { wish.done = checkbox.checked; save('wishes', wishes); });
      remove.addEventListener('click', () => {
        wishes = wishes.filter((item) => item !== wish);
        save('wishes', wishes);
        renderWishes();
        const nextControl = $('wish-list').children[Math.min(index, wishes.length - 1)]?.querySelector('input') || $('wish-input');
        nextControl.focus();
      });
      row.append(label, remove);
      $('wish-list').append(row);
    });
  }
  renderWishes();
  $('wish-form').addEventListener('submit', (event) => {
    event.preventDefault();
    const text = $('wish-input').value.trim();
    if (!text) { $('wish-input').setCustomValidity('Add a little wish first.'); $('wish-input').reportValidity(); return; }
    if (wishes.length >= 20) { announce('Your chapter has 20 wishes. Remove one to make room for another.'); return; }
    wishes.push({ id: `wish-${Date.now()}-${Math.random().toString(36).slice(2)}`, text, done: false });
    const saved = save('wishes', wishes);
    renderWishes();
    $('wish-input').value = '';
    $('wish-input').focus();
    if (saved) announce('One more little thing to look forward to. ♡');
  });
  $('wish-input').addEventListener('input', () => $('wish-input').setCustomValidity(''));

  // Device originals and the shared cache have separate stores and never overwrite each other.
  const deviceMemories = new Map();
  let memories = deviceMemories;
  const cloud = window.AnniCloud;
  let sharedMode = false;
  let devicePhotosImported = false;
  let localStorageNote = $('storage-note').textContent;
  let selectedSlot = null;
  let albumPage = 0;
  const maxPhotos = 24;
  const spreadSize = 4;
  let activePhoto = 0;
  let photoBusy = false;
  let refreshing = false;
  function storageUnavailable() {
    localStorageNote = 'Photos are available for this visit, but this browser could not save them. Keep your originals; they will not travel with shared page files.';
    if (!sharedMode) $('storage-note').textContent = localStorageNote;
  }
  function sharedStatus(message) { $('shared-album-status').textContent = message; }
  function useSharedSnapshot(photos) {
    const next = new Map();
    try {
      for (const item of photos) next.set(item.slot, { ...item, url: URL.createObjectURL(item.blob) });
    } catch (error) { for (const item of next.values()) URL.revokeObjectURL(item.url); throw error; }
    if (memories !== deviceMemories) for (const item of memories.values()) URL.revokeObjectURL(item.url);
    if ($('photo-dialog').open) $('photo-dialog').close();
    memories = next;
    sharedMode = true;
  }
  function renderSharedControls() {
    const offline = sharedMode && !cloud?.online;
    document.querySelector('.shared-album-panel').dataset.connected = String(sharedMode);
    $('shared-album-code').disabled = photoBusy || !photosLoaded || !cloud;
    $('connect-album').disabled = photoBusy || !photosLoaded || !cloud;
    $('shared-album-controls').hidden = !sharedMode;
    $('disconnect-album').disabled = photoBusy;
    $('upload-device-photos').hidden = !sharedMode || !deviceMemories.size || devicePhotosImported;
    $('upload-device-photos').disabled = photoBusy || offline || memories.size >= maxPhotos;
    $('refresh-label').textContent = refreshing ? 'Refreshing...' : (sharedMode ? 'Refresh album' : 'Refresh page');
    $('refresh-button').setAttribute('aria-busy', String(refreshing));
    if (sharedMode) $('storage-note').textContent = offline
      ? 'Viewing the last saved shared album. Connect to the internet and tap Refresh album to see new photos or make changes. Your device album is still kept separately.'
      : 'Photos and captions in this album are shared with devices using our private code. Tap Refresh album on the other device to see updates.' + (cloud.cacheHealthy ? '' : ' This device could not keep an offline copy.');
    else $('storage-note').textContent = localStorageNote;
  }
  async function recoverSharedConflict(error) {
    if (error.status !== 409) return;
    try { useSharedSnapshot(await cloud.refresh()); } catch { /* Keep the last complete snapshot visible. */ }
  }
  const database = new Promise((resolve) => {
    if (!window.indexedDB) { storageUnavailable(); resolve(null); return; }
    let settled = false;
    const finish = (db) => { if (settled) { db?.close(); return; } settled = true; clearTimeout(timeout); if (!db) storageUnavailable(); resolve(db); };
    const timeout = setTimeout(() => finish(null), 4000);
    try {
      const request = indexedDB.open('anni-memory-photos-v1', 1);
      request.onupgradeneeded = () => { if (!request.result.objectStoreNames.contains('photos')) request.result.createObjectStore('photos', { keyPath: 'slot' }); };
      request.onsuccess = () => finish(request.result);
      request.onerror = () => finish(null);
      request.onblocked = () => finish(null);
    } catch { finish(null); }
  });
  async function photoOperation(mode, operation) {
    const db = await database;
    if (!db) return false;
    try {
      await new Promise((resolve, reject) => {
        const tx = db.transaction('photos', mode);
        operation(tx.objectStore('photos'));
        tx.oncomplete = resolve;
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error);
      });
      return true;
    } catch { storageUnavailable(); return false; }
  }
  function sortedSlots() { return [...memories.keys()].sort((a, b) => a - b); }
  function element(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }
  function renderAlbum(focusSlot = null) {
    const editingDisabled = photoBusy || sharedMode && !cloud?.online;
    const highestSlot = Math.max(-1, ...memories.keys());
    const spreads = Math.max(1, Math.ceil((highestSlot + 1) / spreadSize));
    albumPage = Math.max(0, Math.min(albumPage, spreads - 1));
    const grid = $('memory-grid');
    const cards = [];
    for (let position = 0; position < spreadSize; position++) {
      const slot = albumPage * spreadSize + position;
      const item = memories.get(slot);
      const card = element('article', 'memory-card');
      card.dataset.slot = slot;
      const button = element('button', 'memory-photo');
      button.type = 'button';
      button.dataset.photo = slot;
      button.disabled = photoBusy || !item && editingDisabled;
      button.setAttribute('aria-label', item ? 'View memory ' + (slot + 1) + (item.caption ? ': ' + item.caption : '') : 'Add photo for memory ' + (slot + 1));
      if (item) {
        button.classList.add('has-photo');
        button.setAttribute('aria-haspopup', 'dialog');
        button.setAttribute('aria-controls', 'photo-dialog');
        const image = element('img');
        image.src = item.url;
        image.alt = item.caption || 'Our memory ' + (slot + 1);
        image.loading = 'lazy';
        button.append(image);
      } else {
        const placeholder = element('span', 'photo-placeholder');
        const plus = element('span', '', '+');
        plus.setAttribute('aria-hidden', 'true');
        placeholder.append(plus, document.createTextNode('Add photo'));
        button.append(placeholder);
      }
      const label = element('label', 'sr-only', 'Caption for memory ' + (slot + 1));
      label.htmlFor = 'caption-' + slot;
      const caption = element('input', 'memory-caption');
      caption.id = 'caption-' + slot;
      caption.dataset.caption = slot;
      caption.type = 'text';
      caption.maxLength = 60;
      caption.placeholder = 'A little moment...';
      caption.value = item ? item.caption : '';
      caption.disabled = !item || editingDisabled;
      caption.setAttribute('aria-describedby', 'photo-note');
      const tools = element('div', 'memory-tools');
      tools.hidden = !item;
      const replace = element('button', '', 'Change');
      replace.type = 'button';
      replace.dataset.replace = slot;
      replace.disabled = editingDisabled;
      replace.setAttribute('aria-label', 'Change photo for memory ' + (slot + 1));
      const remove = element('button', '', 'Remove');
      remove.type = 'button';
      remove.dataset.remove = slot;
      remove.disabled = editingDisabled;
      remove.setAttribute('aria-label', 'Remove photo for memory ' + (slot + 1));
      tools.append(replace, remove);
      card.append(button, label, caption, tools);
      cards.push(card);
    }
    grid.replaceChildren(...cards);
    grid.setAttribute('aria-busy', String(photoBusy));
    $('album-count').textContent = memories.size + (memories.size === 1 ? ' photo' : ' photos');
    $('album-page-label').textContent = 'Spread ' + (albumPage + 1) + ' of ' + spreads;
    $('previous-spread').disabled = photoBusy || albumPage === 0;
    $('next-spread').disabled = photoBusy || albumPage >= spreads - 1;
    $('add-photos').disabled = editingDisabled || memories.size >= maxPhotos;
    $('add-photos').textContent = photoBusy ? 'Adding photos...' : '+ Add photos';
    $('refresh-button').disabled = refreshing || photoBusy || !photosLoaded;
    renderSharedControls();
    if (focusSlot !== null) {
      const target = grid.querySelector('[data-photo="' + focusSlot + '"]') || grid.querySelector('[data-photo]');
      focusIfVisible(target);
    }
  }
  let photosLoaded = false;
  const photosReady = (async () => {
    const entries = [];
    await photoOperation('readonly', (store) => {
      const request = store.getAll();
      request.onsuccess = () => entries.push(...request.result);
    });
    for (const item of entries) {
      if (!Number.isInteger(item.slot) || item.slot < 0 || item.slot >= maxPhotos || !(item.blob instanceof Blob)) continue;
      memories.set(item.slot, {
        blob: item.blob,
        caption: typeof item.caption === 'string' ? item.caption.slice(0, 60) : '',
        url: URL.createObjectURL(item.blob)
      });
    }
  })().catch(() => storageUnavailable()).finally(() => {
    photosLoaded = true;
    renderAlbum();
  });
  const sharedReady = photosReady.then(async () => {
    if (!cloud) { sharedStatus('The shared album connection is not available in this copy. Your device album is ready.'); return; }
    $('shared-album-setup').href = cloud.setupUrl;
    $('shared-album-code').value = cloud.savedCode;
    if (!cloud.savedCode) return;
    photoBusy = true;
    renderAlbum();
    sharedStatus('Opening our shared album...');
    try {
      const result = await cloud.restore();
      if (result.connected) {
        useSharedSnapshot(result.photos);
        sharedStatus(result.offline ? 'Showing our last saved shared album. Tap Refresh album when you are online.' : 'Our shared album is connected. Refresh this album to see photos from the other device.');
      }
    } catch (error) { sharedStatus(error.message + ' Your device album is still available.'); }
    finally { photoBusy = false; renderAlbum(); }
  });
  $('shared-album-form').addEventListener('submit', async event => {
    event.preventDefault();
    if (!cloud || photoBusy || !photosLoaded) return;
    photoBusy = true;
    renderAlbum();
    sharedStatus('Connecting our shared album...');
    try {
      const result = await cloud.connect($('shared-album-code').value);
      useSharedSnapshot(result.photos);
      devicePhotosImported = false;
      albumPage = 0;
      sharedStatus('Connected. Both devices using this code can upload photos and refresh to see them. Device originals are kept separately.');
    } catch (error) { sharedStatus(error.message); }
    finally { photoBusy = false; renderAlbum(); }
  });
  $('disconnect-album').addEventListener('click', async () => {
    if (!cloud || photoBusy) return;
    photoBusy = true;
    renderAlbum();
    try {
      await cloud.disconnect();
      for (const item of memories.values()) URL.revokeObjectURL(item.url);
      memories = deviceMemories;
      sharedMode = false;
      devicePhotosImported = false;
      $('shared-album-code').value = '';
      albumPage = 0;
      sharedStatus('Your device album is open. Shared photos are still online and can be opened again with our code.');
    } finally { photoBusy = false; renderAlbum(); }
  });
  $('refresh-button').addEventListener('click', async () => {
    if (refreshing || photoBusy || !photosLoaded) return;
    refreshing = true;
    $('refresh-button').disabled = true;
    $('refresh-button').setAttribute('aria-busy', 'true');
    $('refresh-label').textContent = 'Refreshing...';
    if (sharedMode) {
      photoBusy = true;
      renderAlbum();
      try {
        useSharedSnapshot(await cloud.refresh());
        sharedStatus('Our shared album is up to date. ♡');
        announce('Shared album refreshed. ♡');
      } catch (error) { sharedStatus(error.message + ' The last complete album is still here.'); }
      finally { refreshing = false; photoBusy = false; renderAlbum(); }
      return;
    }
    // Wait behind caption/removal transactions before navigating. Saved data stays intact.
    await photoOperation('readonly', () => {});
    window.location.reload();
  });
  function choosePhoto(slot = null) {
    if (photoBusy || !photosLoaded || sharedMode && !cloud?.online) return;
    selectedSlot = slot;
    $('photo-input').multiple = slot === null;
    $('photo-input').value = '';
    $('photo-input').click();
  }
  function showPhoto(slot) {
    const item = memories.get(slot);
    if (!item) return;
    activePhoto = slot;
    $('full-photo').src = item.url;
    $('full-photo').alt = item.caption || 'Our memory ' + (slot + 1);
    $('full-caption').textContent = item.caption || 'A little moment, kept close. ♡';
    const slots = sortedSlots();
    $('photo-position').textContent = (slots.indexOf(slot) + 1) + ' of ' + slots.length;
    $('previous-photo').disabled = slots.length < 2;
    $('next-photo').disabled = slots.length < 2;
  }
  $('add-photos').addEventListener('click', () => choosePhoto());
  $('previous-spread').addEventListener('click', () => {
    albumPage--;
    renderAlbum();
    if ($('previous-spread').disabled) $('next-spread').focus();
  });
  $('next-spread').addEventListener('click', () => {
    albumPage++;
    renderAlbum();
    if ($('next-spread').disabled) $('previous-spread').focus();
  });
  $('memory-grid').addEventListener('click', async (event) => {
    const button = event.target.closest('button[data-photo], button[data-replace], button[data-remove]');
    if (!button || photoBusy || !$('memory-grid').contains(button)) return;
    if (button.hasAttribute('data-photo')) {
      const slot = Number(button.dataset.photo);
      if (memories.has(slot)) { showPhoto(slot); openDialog($('photo-dialog')); }
      else choosePhoto(slot);
    } else if (button.hasAttribute('data-replace')) choosePhoto(Number(button.dataset.replace));
    else {
      const slot = Number(button.dataset.remove);
      const item = memories.get(slot);
      if (!item) return;
      if (sharedMode) {
        photoBusy = true;
        renderAlbum();
        try {
          await cloud.remove(item);
          useSharedSnapshot(cloud.snapshot());
          sharedStatus('Photo removed from our shared album. Your device originals are unchanged.');
          announce('Photo removed from our shared album.');
        } catch (error) { await recoverSharedConflict(error); sharedStatus(error.message); announce(error.message); }
        finally { photoBusy = false; renderAlbum(slot); }
        return;
      }
      memories.delete(slot);
      if ($('full-photo').getAttribute('src') === item.url) $('full-photo').removeAttribute('src');
      renderAlbum(slot);
      URL.revokeObjectURL(item.url);
      const saved = await photoOperation('readwrite', (store) => store.delete(slot));
      announce(saved ? 'Photo removed from this album. Your original file is safe.' : 'Photo removed for this visit. The browser could not save that change.');
    }
  });
  $('memory-grid').addEventListener('change', async (event) => {
    const caption = event.target.closest('input[data-caption]');
    if (!caption) return;
    const slot = Number(caption.dataset.caption);
    const item = memories.get(slot);
    if (!item) return;
    if (sharedMode) {
      const nextCaption = caption.value.trim();
      photoBusy = true;
      renderAlbum();
      try {
        await cloud.updateCaption(item, nextCaption);
        useSharedSnapshot(cloud.snapshot());
        sharedStatus('Caption saved to our shared album. Refresh the other device to see it.');
      } catch (error) { await recoverSharedConflict(error); sharedStatus(error.message); announce(error.message); }
      finally { photoBusy = false; renderAlbum(); }
      return;
    }
    item.caption = caption.value.trim();
    caption.value = item.caption;
    const button = $('memory-grid').querySelector('[data-photo="' + slot + '"]');
    button?.setAttribute('aria-label', 'View memory ' + (slot + 1) + (item.caption ? ': ' + item.caption : ''));
    const image = button?.querySelector('img');
    if (image) image.alt = item.caption || 'Our memory ' + (slot + 1);
    const saved = await photoOperation('readwrite', (store) => store.put({ slot, blob: item.blob, caption: item.caption }));
    if (!saved) announce('Caption kept for this visit. The browser could not save it.');
  });
  async function uploadSharedPhotos(items, replacementSlot = null) {
    if (!sharedMode || photoBusy || !cloud.online) return;
    photoBusy = true;
    renderAlbum();
    let added = 0;
    let failed = 0;
    let lastSlot = null;
    let failureMessage = '';
    try {
      for (const entry of items) {
        const photo = entry.blob;
        if (replacementSlot === null && cloud.snapshot().length >= maxPhotos) { failureMessage = 'This shared album holds up to 24 photos.'; break; }
        if (!(photo instanceof Blob) || !photo.type.startsWith('image/') || photo.size > 20 * 1024 * 1024) { failed++; continue; }
        let previewUrl;
        try {
          previewUrl = URL.createObjectURL(photo);
          const image = new Image(); image.src = previewUrl; await image.decode();
          const previous = replacementSlot === null ? null : memories.get(replacementSlot);
          const result = previous ? await cloud.replace(previous, photo, previous.caption) : await cloud.add(photo, entry.caption || '');
          added++; lastSlot = result.slot;
        } catch (error) {
          failed++;
          failureMessage = error.name === 'CloudError' ? error.message : 'A photo could not be opened or uploaded.';
          await recoverSharedConflict(error);
          if (error.status === 409 || error.status === 401 || error.status === 403 || error.status === 507 || !cloud.online) break;
        } finally { if (previewUrl) URL.revokeObjectURL(previewUrl); }
      }
    } finally {
      useSharedSnapshot(cloud.snapshot());
      photoBusy = false;
      if (lastSlot !== null) albumPage = Math.floor(lastSlot / spreadSize);
      renderAlbum(lastSlot);
      let message = added ? (replacementSlot !== null ? 'Photo changed in our shared album.' : added + (added === 1 ? ' photo uploaded to our shared album.' : ' photos uploaded to our shared album.')) + ' Refresh the other device to see the updates. ♡' : 'No photos were uploaded.';
      if (failed && !failureMessage) message += ' ' + failed + ' could not be opened or exceeded 20 MB.';
      if (failureMessage) message += ' ' + failureMessage;
      sharedStatus(message);
      announce(message);
    }
    return { added, failed, complete: added === items.length };
  }
  $('upload-device-photos').addEventListener('click', async () => {
    if (!sharedMode || photoBusy) return;
    const result = await uploadSharedPhotos([...deviceMemories.values()].map(item => ({ blob: item.blob, caption: item.caption })));
    if (result?.complete) { devicePhotosImported = true; renderSharedControls(); }
  });
  $('photo-input').addEventListener('change', async (event) => {
    const replacing = selectedSlot !== null;
    const files = Array.from(event.target.files).slice(0, replacing ? 1 : maxPhotos);
    if (!files.length || photoBusy) return;
    if (sharedMode) { await uploadSharedPhotos(files.map(blob => ({ blob })), replacing ? selectedSlot : null); return; }
    const replacementSlot = selectedSlot;
    photoBusy = true;
    renderAlbum();
    let added = 0;
    let failed = 0;
    let unsaved = 0;
    let full = false;
    let lastSlot = null;
    try {
      await photosReady;
      for (const file of files) {
        const slot = replacing ? replacementSlot : Array.from({ length: maxPhotos }, (_, index) => index).find((index) => !memories.has(index));
        if (slot === undefined) { full = true; break; }
        if (!file.type.startsWith('image/') || file.size > 20 * 1024 * 1024) { failed++; continue; }
        let nextUrl;
        try {
          nextUrl = URL.createObjectURL(file);
          const image = new Image();
          image.src = nextUrl;
          await image.decode();
          const previous = memories.get(slot);
          const item = { blob: file, caption: previous?.caption || '', url: nextUrl };
          memories.set(slot, item);
          if (previous) {
            if ($('full-photo').getAttribute('src') === previous.url) $('full-photo').removeAttribute('src');
            URL.revokeObjectURL(previous.url);
          }
          added++;
          lastSlot = slot;
          const saved = await photoOperation('readwrite', (store) => store.put({ slot, blob: file, caption: item.caption }));
          if (!saved) unsaved++;
        } catch {
          if (nextUrl) URL.revokeObjectURL(nextUrl);
          failed++;
        }
      }
    } finally {
      photoBusy = false;
      if (lastSlot !== null) albumPage = Math.floor(lastSlot / spreadSize);
      renderAlbum(lastSlot);
      if (lastSlot === null) focusIfVisible($('add-photos'));
      let message = added ? (replacing ? 'Photo changed.' : added + (added === 1 ? ' photo added to our album.' : ' photos added to our album.')) : 'No photos were added.';
      if (unsaved) message += ' ' + unsaved + ' could not be saved on this device and will last for this visit.';
      else if (added) message += ' Saved on this device. ♡';
      if (failed) message += ' ' + failed + ' could not be opened or exceeded 20 MB.';
      if (full) message += ' This album holds up to ' + maxPhotos + ' photos.';
      announce(message);
    }
  });
  function movePhoto(direction) {
    const slots = sortedSlots();
    if (!slots.length) return;
    showPhoto(slots[(slots.indexOf(activePhoto) + direction + slots.length) % slots.length]);
  }
  $('previous-photo').addEventListener('click', () => movePhoto(-1));
  $('next-photo').addEventListener('click', () => movePhoto(1));
  $('photo-dialog').addEventListener('keydown', (event) => {
    if (event.key === 'ArrowLeft') { event.preventDefault(); movePhoto(-1); }
    if (event.key === 'ArrowRight') { event.preventDefault(); movePhoto(1); }
  });
  $('photo-dialog').addEventListener('close', () => $('full-photo').removeAttribute('src'));
})();
