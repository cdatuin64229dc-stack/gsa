(() => {
  'use strict';

  const welcome = document.getElementById('welcome-screen');
  const page = document.getElementById('anniversary-page');
  const button = document.getElementById('open-surprise');
  const speech = document.getElementById('entrance-speech');
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  if (!welcome || !page || !button) return;
  let opening = false;
  let entered = false;
  let revealTimer;

  function celebrate() {
    if (reducedMotion.matches || document.hidden) return;
    const layer = document.getElementById('heart-burst');
    if (!layer) return;
    for (let index = 0; index < 24; index++) {
      const particle = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      const symbol = document.createElementNS('http://www.w3.org/2000/svg', 'use');
      symbol.setAttribute('href', index % 4 === 0 ? '#puffy-white-star' : '#puffy-heart');
      particle.append(symbol);
      particle.setAttribute('viewBox', '0 0 40 40');
      particle.setAttribute('focusable', 'false');
      particle.classList.add('entrance-particle');
      particle.style.left = (window.innerWidth * (.24 + Math.random() * .52)) + 'px';
      particle.style.top = (window.innerHeight * (.55 + Math.random() * .25)) + 'px';
      particle.style.setProperty('--size', (16 + Math.random() * 20) + 'px');
      particle.style.setProperty('--drift', ((Math.random() - .5) * window.innerWidth * .6) + 'px');
      particle.style.setProperty('--turn', ((Math.random() - .5) * 100) + 'deg');
      layer.append(particle);
      setTimeout(() => particle.remove(), 2200);
    }
  }
  function finishEntry(withCelebration = true) {
    if (entered) return;
    entered = true;
    clearTimeout(revealTimer);
    welcome.hidden = true;
    welcome.inert = true;
    page.hidden = false;
    page.inert = false;
    document.documentElement.classList.remove('welcome-active');
    document.title = 'Happy 1st Anniversary, beby!!';
    window.scrollTo(0, 0);
    const heading = page.querySelector('h1');
    if (heading) { heading.tabIndex = -1; heading.focus({ preventScroll: true }); }
    document.dispatchEvent(new CustomEvent('anni:entered'));
    if (withCelebration) celebrate();
    setTimeout(() => page.classList.remove('is-revealing'), 1200);
  }
  button.addEventListener('click', () => {
    if (opening || entered) return;
    opening = true;
    button.disabled = true;
    button.setAttribute('aria-busy', 'true');
    speech.textContent = 'Ready? ♡';
    page.hidden = false;
    page.inert = true;
    if (reducedMotion.matches) { finishEntry(false); return; }
    page.classList.add('is-revealing');
    welcome.classList.add('is-opening');
    revealTimer = setTimeout(() => finishEntry(), 850);
  });
  welcome.addEventListener('animationend', event => {
    if (event.target === welcome && event.animationName === 'entrance-open' && opening) finishEntry();
  });
  document.addEventListener('visibilitychange', () => { if (opening && !entered && document.hidden) finishEntry(false); });
  window.addEventListener('pagehide', () => { if (opening && !entered) finishEntry(false); });
})();
