(() => {
  'use strict';

  const ids = ['story-home', 'love-letter', 'photo-album', 'next-chapter', 'special-dates'];
  const pages = ids.map(id => document.getElementById(id));
  const app = document.getElementById('anniversary-page');
  const navigation = document.getElementById('journey-category-nav');
  const pager = document.getElementById('page-controls');
  const previousButton = document.getElementById('page-previous');
  const nextButton = document.getElementById('page-next');
  if (!app || pages.some(page => !page) || !navigation || !pager || !previousButton || !nextButton) return;

  const names = pages.map(page => page.dataset.pageTitle);
  const scrollPositions = new Map();
  const session = 'journey-' + Date.now().toString(36) + Math.random().toString(36).slice(2);
  let current = 0;
  let depth = 0;
  let backPending = false;
  let backTimer;
  let entered = !document.documentElement.classList.contains('welcome-active') && !app.hidden;

  function pageFromHash() {
    let value;
    try { value = decodeURIComponent(location.hash.slice(1)); } catch { return 0; }
    if (value === 'letter-dialog') return 1;
    const direct = ids.indexOf(value);
    if (direct >= 0) return direct;
    const parent = document.getElementById(value)?.closest('[data-app-page]');
    return Math.max(0, ids.indexOf(parent?.id));
  }
  function stateFor(index, level) {
    const existing = history.state && typeof history.state === 'object' ? history.state : {};
    return { ...existing, ourJourneyPage: { session, id: ids[index], depth: level } };
  }
  function urlFor(index) {
    const url = new URL(location.href);
    url.hash = ids[index];
    return url.href;
  }
  function closeDialogs() {
    for (const dialog of document.querySelectorAll('dialog[open]')) dialog.close();
    if (!document.querySelector('dialog[open]')) document.documentElement.classList.remove('dialog-open');
  }
  function focusHeading() {
    if (!entered) return;
    const heading = pages[current].querySelector('h1, h2');
    if (heading) {
      heading.tabIndex = -1;
      heading.focus({ preventScroll: true });
    }
  }
  function measurePager() {
    const height = pager.getBoundingClientRect().height;
    if (height > 0) document.documentElement.style.setProperty('--journey-dock-height', Math.ceil(height) + 'px');
  }
  function show(index, { restoreScroll = false, focus = true, announce = true } = {}) {
    const changed = index !== current;
    if (entered && changed) scrollPositions.set(ids[current], window.scrollY);
    if (changed) closeDialogs();
    current = index;
    pages.forEach((page, position) => {
      const active = position === current;
      page.hidden = !active;
      page.inert = !active;
      page.classList.toggle('is-current', active);
      if (active) page.removeAttribute('aria-hidden');
      else page.setAttribute('aria-hidden', 'true');
    });
    app.dataset.currentPage = ids[current];
    for (const link of navigation.querySelectorAll('[data-page-target]')) {
      if (link.dataset.pageTarget === ids[current]) link.setAttribute('aria-current', 'page');
      else link.removeAttribute('aria-current');
    }
    document.getElementById('current-page-name').textContent = names[current];
    document.getElementById('page-current-title').textContent = names[current];
    document.getElementById('page-position').textContent = (current + 1) + ' / ' + pages.length;
    previousButton.disabled = current === 0;
    const nextIndex = (current + 1) % pages.length;
    document.getElementById('page-next-label').textContent = nextIndex === 0 ? 'Home' : 'Next';
    document.getElementById('page-next-destination').textContent = nextIndex === 0 ? 'Our beginning' : names[nextIndex];
    nextButton.setAttribute('aria-label', nextIndex === 0 ? 'Back to our Home category' : 'Next category: ' + names[nextIndex]);
    previousButton.setAttribute('aria-label', current === 0 ? 'Back: you are at the beginning' : 'Back to the previous category');
    navigation.inert = !entered;
    pager.inert = !entered;
    pager.hidden = false;
    if (entered) {
      document.title = current === 0 ? 'Happy 1st Anniversary, beby!! · Our Journey' : names[current] + ' · Our Journey';
      if (changed || focus) window.scrollTo({ top: restoreScroll ? (scrollPositions.get(ids[current]) || 0) : 0, behavior: 'instant' });
      if (focus) focusHeading();
      if (announce && changed) document.getElementById('page-announcement').textContent = names[current] + ', page ' + (current + 1) + ' of ' + pages.length;
    }
    measurePager();
    if (changed || announce) document.dispatchEvent(new CustomEvent('anni:pagechange', { detail: { id: ids[current], index: current, total: pages.length, title: names[current] } }));
  }
  function goTo(id, options = {}) {
    const index = ids.indexOf(String(id).replace(/^#/, ''));
    if (index < 0) return false;
    if (index === current) {
      if (entered && options.focus !== false) { window.scrollTo({ top: 0, behavior: 'instant' }); focusHeading(); }
      return true;
    }
    const nextDepth = options.replace ? depth : depth + 1;
    try {
      history[options.replace ? 'replaceState' : 'pushState'](stateFor(index, nextDepth), '', urlFor(index));
      depth = nextDepth;
    } catch {
      depth = 0;
      location.hash = ids[index];
    }
    show(index, options);
    return true;
  }
  function back() {
    if (!entered || document.documentElement.classList.contains('welcome-active') || current === 0) return false;
    if (backPending) return true;
    const state = history.state?.ourJourneyPage;
    if (depth > 0 && state?.session === session) {
      backPending = true;
      history.back();
      clearTimeout(backTimer);
      backTimer = setTimeout(() => { backPending = false; }, 500);
      return true;
    }
    return goTo(ids[current - 1], { replace: true, restoreScroll: true });
  }
  function syncLocation() {
    backPending = false;
    clearTimeout(backTimer);
    const index = pageFromHash();
    const state = history.state?.ourJourneyPage;
    depth = state?.session === session && state.id === ids[index] ? Math.max(0, Number(state.depth) || 0) : 0;
    if (state?.session !== session || state.id !== ids[index]) {
      try { history.replaceState(stateFor(index, depth), '', location.href); } catch { /* Hash navigation still works. */ }
    }
    if (index !== current) {
      show(index, { restoreScroll: true });
      // Chrome restores its own focus after popstate; finish the page's focus
      // handoff once that history traversal has completed.
      setTimeout(() => { if (entered && current === index) focusHeading(); }, 0);
    }
  }

  window.AnniPages = Object.freeze({
    goTo,
    next() { return entered ? goTo(ids[(current + 1) % pages.length]) : false; },
    previous: back,
    back,
    get currentPage() { return ids[current]; },
    get currentIndex() { return current; },
    get totalPages() { return pages.length; }
  });
  document.documentElement.classList.add('app-paged');
  current = pageFromHash();
  try { history.replaceState(stateFor(current, 0), '', location.href); } catch { /* URL changes are optional for navigation. */ }
  show(current, { focus: false, announce: false });
  navigation.addEventListener('click', event => {
    const link = event.target.closest('a[data-page-target]');
    if (!link || !navigation.contains(link) || event.button !== 0 || event.ctrlKey || event.metaKey || event.altKey || event.shiftKey) return;
    event.preventDefault();
    goTo(link.dataset.pageTarget);
  });
  previousButton.addEventListener('click', back);
  nextButton.addEventListener('click', () => window.AnniPages.next());
  window.addEventListener('popstate', syncLocation);
  window.addEventListener('hashchange', syncLocation);
  document.addEventListener('anni:entered', () => {
    entered = true;
    navigation.inert = false;
    pager.inert = false;
    show(current, { focus: true, announce: false });
  });
  window.addEventListener('resize', measurePager);
  if ('ResizeObserver' in window) new ResizeObserver(measurePager).observe(pager);
})();
